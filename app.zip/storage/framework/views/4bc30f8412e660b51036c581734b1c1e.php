Has recibido un email nuevo: <?php echo e($data['subject']); ?> <br><br>

Datos personales: <br><br>

Nombre: <?php echo e($data['name']); ?> <br>
Email: <?php echo e($data['email']); ?> <br>
Numero de teléfono: <?php echo e($data['phone']); ?> <br>
Subject: <?php echo e($data['subject']); ?> <br>
Message: <?php echo e($data['message']); ?> <br><br>

Thanks<?php /**PATH C:\laragon\www\newkool\resources\views/mail.blade.php ENDPATH**/ ?>