Has recibido un email nuevo: {{ $data['subject'] }} <br><br>

Datos personales: <br><br>

Nombre: {{ $data['name'] }} <br>
Email: {{ $data['email'] }} <br>
Numero de teléfono: {{ $data['phone'] }} <br>
Subject: {{ $data['subject'] }} <br>
Message: {{ $data['message'] }} <br><br>

Thanks