<script setup>
import { Head, Link } from '@inertiajs/vue3';

</script>

<template>
    <Link :href="'/'">
        <slot></slot>
    </Link>
</template>



